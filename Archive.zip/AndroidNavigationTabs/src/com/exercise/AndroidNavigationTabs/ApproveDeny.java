package com.exercise.AndroidNavigationTabs;

import java.util.ArrayList;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class ApproveDeny extends Fragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myFragmentView = inflater.inflate(R.layout.approve_deny_l,
				container, false);

		Button btn_select = (Button) myFragmentView
				.findViewById(R.id.btnSelect);
		Button btn_unselect = (Button) myFragmentView
				.findViewById(R.id.btnUnselect);

		final Button btn_deny = (Button) myFragmentView
				.findViewById(R.id.btnDeny);
		final Button btn_approve = (Button) myFragmentView
				.findViewById(R.id.btnApprove);

		final ListView approve_deny = (ListView) myFragmentView
				.findViewById(R.id.approveDenyList);

		ArrayList<String> approve_deny_list = new ArrayList<String>();
		approve_deny_list.add("aa");
		approve_deny_list.add("bb");
		approve_deny_list.add("cc");
		approve_deny_list.add("dd");
		approve_deny_list.add("ee");

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(
				myFragmentView.getContext(),
				android.R.layout.simple_list_item_multiple_choice,
				approve_deny_list);
		approve_deny.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
		approve_deny.setAdapter(adapter);

		btn_select.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				btn_deny.setVisibility(View.VISIBLE);
				btn_approve.setVisibility(View.VISIBLE);
				
				for(int i = 0; i < approve_deny.getChildCount(); i++){
					approve_deny.setItemChecked(i, true);
				}
			}

		});

		btn_unselect.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				btn_deny.setVisibility(View.GONE);
				btn_approve.setVisibility(View.GONE);
				
				for(int i = 0; i < approve_deny.getChildCount(); i++){
					approve_deny.setItemChecked(i, false);
				}
			}

		});

		btn_deny.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

			}

		});

		btn_approve.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

			}

		});

		return myFragmentView;
	}

}
