package com.exercise.AndroidNavigationTabs;

import java.util.Calendar;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

public class RequestLeave extends Fragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		final View myFragmentView = inflater.inflate(R.layout.request_leave_l, container, false);
		
		TextView sick_days = (TextView) myFragmentView.findViewById(R.id.sickDays);
		sick_days.setText("s");
		
		TextView personal_days = (TextView) myFragmentView.findViewById(R.id.personalDays);
		personal_days.setText("p");
		
		TextView vacation_days = (TextView) myFragmentView.findViewById(R.id.vacationDays);
		vacation_days.setText("v");
		
		final TextView edt_start = (TextView) myFragmentView.findViewById(R.id.startLeave);
		
		final Handler mHandler = new Handler(){
	        @Override
	        public void handleMessage(Message m){
	        	/** Creating a bundle object to pass currently set date to the fragment */
	            Bundle b = m.getData();
	 
	            b.getInt("set_day");
	 
	            b.getInt("set_month");
	 
	            b.getInt("set_year");
	 
	            /** Displaying a short time message containing date set by Date picker dialog fragment */
	            //Toast.makeText(getView().getContext(), b.getString("set_date"), Toast.LENGTH_SHORT).show();
	            String s = b.getString("set_date").substring("Set Date : ".length(), b.getString("set_date").length());
	            String d[] = s.split("/");
	            edt_start.setText(d[1] + "/" + d[0] + "/" + d[2]);
	        }
	    };
	    final TextView edt_end = (TextView) myFragmentView.findViewById(R.id.endLeave);
	    
	    final Handler mHandler1 = new Handler(){
	        @Override
	        public void handleMessage(Message m){
	        	/** Creating a bundle object to pass currently set date to the fragment */
	            Bundle b = m.getData();
	 
	            b.getInt("set_day");
	 
	            b.getInt("set_month");
	 
	            b.getInt("set_year");
	 
	            /** Displaying a short time message containing date set by Date picker dialog fragment */
	            //Toast.makeText(getView().getContext(), b.getString("set_date"), Toast.LENGTH_SHORT).show();
	            String s = b.getString("set_date").substring("Set Date : ".length(), b.getString("set_date").length());
	            String d[] = s.split("/");
	            edt_end.setText(d[1] + "/" + d[0] + "/" + d[2]);
	        }
	    };
		
		edt_start.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
			    int mDay = c.get(Calendar.DATE), mMonth = c.get(Calendar.MONTH), mYear = c.get(Calendar.YEAR);
			    /** Creating a bundle object to pass currently set date to the fragment */
                Bundle b = new Bundle();
 
                /** Adding currently set day to bundle object */
                b.putInt("set_day", mDay);
 
                /** Adding currently set month to bundle object */
                b.putInt("set_month", mMonth);
 
                /** Adding currently set year to bundle object */
                b.putInt("set_year", mYear);
 
                /** Instantiating DatePickerDialogFragment */
                DatePickerDialogFragment datePicker = new DatePickerDialogFragment(mHandler);
 
                /** Setting the bundle object on datepicker fragment */
                datePicker.setArguments(b);
 
                /** Getting fragment manger for this activity */
                FragmentManager fm = getFragmentManager();
 
                /** Starting a fragment transaction */
                FragmentTransaction ft = fm.beginTransaction();
 
                /** Adding the fragment object to the fragment transaction */
                ft.add(datePicker, "date_picker");
 
                /** Opening the DatePicker fragment */
                ft.commit();
			}
			
		});
    	
    	edt_end.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				Calendar c = Calendar.getInstance();
			    int mDay = c.get(Calendar.DATE), mMonth = c.get(Calendar.MONTH), mYear = c.get(Calendar.YEAR);
			    /** Creating a bundle object to pass currently set date to the fragment */
                Bundle b = new Bundle();
 
                /** Adding currently set day to bundle object */
                b.putInt("set_day", mDay);
 
                /** Adding currently set month to bundle object */
                b.putInt("set_month", mMonth);
 
                /** Adding currently set year to bundle object */
                b.putInt("set_year", mYear);
 
                /** Instantiating DatePickerDialogFragment */
                DatePickerDialogFragment datePicker = new DatePickerDialogFragment(mHandler1);
 
                /** Setting the bundle object on datepicker fragment */
                datePicker.setArguments(b);
 
                /** Getting fragment manger for this activity */
                FragmentManager fm = getFragmentManager();
 
                /** Starting a fragment transaction */
                FragmentTransaction ft = fm.beginTransaction();
 
                /** Adding the fragment object to the fragment transaction */
                ft.add(datePicker, "date_picker");
 
                /** Opening the DatePicker fragment */
                ft.commit();
			}
    		
    	});
    	
    	RadioGroup full_part_leave = (RadioGroup) myFragmentView.findViewById(R.id.fullPartLeave);
		full_part_leave.setOnCheckedChangeListener(new OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
            	TextView txt_end = (TextView) myFragmentView.findViewById(R.id.txtEndLeave);
                switch(checkedId)
                {
                case R.id.fullLeave:
                	txt_end.setVisibility(View.VISIBLE);
                	edt_end.setVisibility(View.VISIBLE);
                    break;
                case R.id.partLeave:
                	txt_end.setVisibility(View.GONE);
                	edt_end.setVisibility(View.GONE);
                    break;
                }
            }
        });
		
		
		
		Button submit = (Button) myFragmentView.findViewById(R.id.reqSubmit);
		
		submit.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
		return myFragmentView;
	}

}
