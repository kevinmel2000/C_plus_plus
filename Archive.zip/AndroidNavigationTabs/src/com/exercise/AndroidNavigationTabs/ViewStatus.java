package com.exercise.AndroidNavigationTabs;

import java.util.ArrayList;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ViewStatus extends Fragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View myFragmentView = inflater.inflate(R.layout.view_status_l,
				container, false);

		ListView view_status = (ListView) myFragmentView
				.findViewById(R.id.viewStatus);

		ArrayList<String> status_list = new ArrayList<String>();
		status_list.add("a");
		status_list.add("b");
		status_list.add("c");
		status_list.add("d");

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(myFragmentView.getContext(),
				android.R.layout.simple_list_item_1, status_list);
		
		view_status.setAdapter(adapter);

		view_status.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub

			}

		});

		return myFragmentView;
	}

}
