package com.exercise.AndroidNavigationTabs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class Login extends Activity{
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		Intent i = new Intent(this, AndroidNavigationTabsActivity.class);
		startActivity(i);
	}
}
