/** Automatically generated file. DO NOT MODIFY */
package com.exercise.AndroidNavigationTabs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}